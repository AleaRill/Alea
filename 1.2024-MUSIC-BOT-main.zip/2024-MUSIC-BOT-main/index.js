
const client = require("./index");
require("./bot");

